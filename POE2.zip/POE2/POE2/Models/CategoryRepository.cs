﻿using POE2.Data;
using System.Linq;

namespace POE2.Models
{
   
        public class CategoryRepository : ICategoryRepository
        {
            private ApplicationDbContext _context;
            public CategoryRepository(ApplicationDbContext context) 
            {
                _context = context;
            }

            public void Update(Category category)
            {
                var categoryDB = _context.Categories.FirstOrDefault(x => x.catID == category.catID);
                if (categoryDB != null)
                {
                    categoryDB.catID = category.catID;
                    categoryDB.CategoryName = category.CategoryName;
                }
            }
        }
    
}
