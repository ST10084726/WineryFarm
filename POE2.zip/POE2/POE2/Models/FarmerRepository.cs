﻿using POE2.Data;
using System.Linq;

namespace POE2.Models
{
    public class FarmerRepository
    {
        private ApplicationDbContext _context;
        public FarmerRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Update(Farmers farmers)
        {
            var famerDb = _context.Farmers.FirstOrDefault(x => x.farmerID == farmers.farmerID);
            if (famerDb != null)
            {
                famerDb.farmerName = farmers.farmerName;
                
            }
        }
    }
}
