﻿namespace POE2.Models
{
    public interface IProductRepository
    {
        void Update(Product product);
    }
}
