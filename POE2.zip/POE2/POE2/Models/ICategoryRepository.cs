﻿namespace POE2.Models
{
    public interface ICategoryRepository
    {
        void Update(Category category);
    }
}
