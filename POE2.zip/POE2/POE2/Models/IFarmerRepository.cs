﻿namespace POE2.Models
{
    public interface IFarmerRepository
    {
        public void Update(Farmers farmers);
    }
}
