﻿using System.ComponentModel.DataAnnotations;

namespace POE2.Models
{
    public class Farmers
    {
        [Key]
        public int farmerID { get; set; }
        public string farmerName { get; set; }
    }
}
