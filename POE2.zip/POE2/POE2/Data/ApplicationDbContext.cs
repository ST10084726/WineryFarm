﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using POE2.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace POE2.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Farmers> Farmers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Category>().HasData(new Category
            {
                catID = 1,
                CategoryName = "Red"

            });
            modelBuilder.Entity<Category>().HasData(new Category
            {
                catID = 2,
                CategoryName = "White"
            });
            modelBuilder.Entity<Category>().HasData(new Category
            {
                catID = 3,
                CategoryName = "Rose"
            });
            modelBuilder.Entity<Category>().HasData(new Category
            {
                catID = 4,
                CategoryName = "Sparkling"
            });
            modelBuilder.Entity<Category>().HasData(new Category
            {
                catID = 5,
                CategoryName = "Non-Alcholic"
            });

            //Product seeding
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ID = 1,
                Name = "Lerato",
                Description = "Smooth",
                Price = 125,
                ImageUrl = "\\images\\Lerato-Sweet-Red.jpg"
            }
            );
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ID = 2,
                Name = "Kanonkop",
                Description = "Blended",
                Price = 125,
                ImageUrl = "\\images\\Kanonkop-pinotage-big-bottle.jpg"
            }
            );
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ID = 3,
                Name = "Peirano Estate Wines",
                Description = "Blended",
                Price = 125,
                ImageUrl = "\\images\\550891_22137.jpg"
            }
            );
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ID = 4,
                Name = "Le Cep d'Argent",
                Description = "Vin Blec White Wine",
                Price = 125,
                ImageUrl = "\\images\\Bout02-IMG_6988_B-JPEG-scaled"
            }
            );
            modelBuilder.Entity<Product>().HasData(new Product
            {
                ID = 5,
                Name = "Ci Bertrand",
                Description = "rose",
                Price = 125,
                ImageUrl = "\\images\\ci-bertrand.jpeg"
            }
            );
           
        }
    }
}
