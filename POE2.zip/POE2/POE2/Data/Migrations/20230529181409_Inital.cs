﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace POE2.Data.Migrations
{
    public partial class Inital : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    catID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.catID);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<double>(type: "float", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CategorycatID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Products_Categories_CategorycatID",
                        column: x => x.CategorycatID,
                        principalTable: "Categories",
                        principalColumn: "catID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "catID", "CategoryName" },
                values: new object[,]
                {
                    { 1, "Red" },
                    { 2, "White" },
                    { 3, "Rose" },
                    { 4, "Sparkling" },
                    { 5, "Non-Alcholic" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ID", "CategorycatID", "Description", "ImageUrl", "Name", "Price" },
                values: new object[,]
                {
                    { 1, null, "Smooth", "\\images\\Lerato-Sweet-Red.jpg", "Lerato", 125.0 },
                    { 2, null, "Blended", "\\images\\Kanonkop-pinotage-big-bottle.jpg", "Kanonkop", 125.0 },
                    { 3, null, "Blended", "\\images\\550891_22137.jpg", "Peirano Estate Wines", 125.0 },
                    { 4, null, "Vin Blec White Wine", "\\images\\Bout02-IMG_6988_B-JPEG-scaled", "Le Cep d'Argent", 125.0 },
                    { 5, null, "rose", "\\images\\ci-bertrand.jpeg", "Ci Bertrand", 125.0 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategorycatID",
                table: "Products",
                column: "CategorycatID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
